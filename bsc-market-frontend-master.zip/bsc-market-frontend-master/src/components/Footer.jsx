import React from 'react'
import { Box } from "@material-ui/core"

function Footer() {
  return (
    <Box>
      <div>        
      </div>
      <div>
      </div>
      
    </Box>
  )
}

export default Footer